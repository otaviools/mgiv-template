<?php
ini_set('display_errors', 0);
error_reporting(0);

header('Content-Type: application/json; charset=utf-8');

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

$nome     = $_POST['nome'] ?? 'Não informado';
$email_usuario = $_POST['email'] ?? 'Não informado';
$telefone = $_POST['telefone'] ?? 'Não informado'; 
$mensagem = $_POST['mensagem'] ?? 'Sem mensagem';

$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host       = 'smtp.hostinger.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'contato@mgiv.com.br'; 
    $mail->Password   = 'SUA_SENHA_AQUI';      
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS; 
    $mail->Port       = 465;
    $mail->CharSet    = 'UTF-8';

    $mail->setFrom('contato@mgiv.com.br', 'Site MGIV - Contato');
    $mail->addAddress('contato@mgiv.com.br'); 
    $mail->addReplyTo($email_usuario, $nome);

    $mail->isHTML(true);
    $mail->Subject = "Novo contato do site MGIV: $nome";
    $mail->Body    = "
        <div style='font-family: sans-serif; border: 1px solid #eee; padding: 20px;'>
            <h2 style='color: #2A5687;'>Novo contato recebido</h2>
            <p><strong>Nome:</strong> $nome</p>
            <p><strong>E-mail:</strong> $email_usuario</p>
            <p><strong>Telefone:</strong> $telefone</p> 
            <p><strong>Mensagem:</strong><br>$mensagem</p>
            <br>
            <hr>
            <p style='font-size: 11px; color: #3A98FF;'>Enviado automaticamente pelo formulário de contato da MGIV.</p>
        </div>
    ";

    $mail->send();
    
    echo json_encode(['status' => 'success', 'message' => 'E-mail enviado com sucesso!']);

} catch (Exception $e) {
    echo json_encode([
        'status' => 'error', 
        'message' => "Erro ao enviar: {$mail->ErrorInfo}"
    ]);
}